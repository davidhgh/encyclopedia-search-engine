package com.example.websearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsearchApplication.class, args);
	}

}
