package com.example.websearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
